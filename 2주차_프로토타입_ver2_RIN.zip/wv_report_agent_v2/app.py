import streamlit as st
import os
import traceback
from datetime import datetime
from rag_module import create_report_rag_chain

# 페이지 설정
st.set_page_config(
    page_title="World Vision 보고서 생성 에이전트",
    page_icon="📊",
    layout="wide"
)

# ==========================================
# 유틸리티 함수
# ==========================================

def check_api_key():
    """API Key 검증"""
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key or api_key == "your-api-key-here":
        return False
    return True

def format_chat_history(messages, max_turns=3):
    """대화 히스토리를 프롬프트에 포함할 수 있도록 포맷팅"""
    if not messages:
        return ""
    
    # 최근 N턴만 사용
    recent_messages = messages[-max_turns*2:] if len(messages) > max_turns*2 else messages
    
    history_text = "\n\n## 이전 대화 맥락\n"
    for msg in recent_messages:
        role = "사용자" if msg["role"] == "user" else "AI"
        history_text += f"{role}: {msg['content']}\n"
    
    return history_text

def safe_invoke_chain(chain, prompt, context=""):
    """에러 핸들링이 적용된 안전한 체인 실행"""
    try:
        # 대화 맥락 포함
        full_prompt = prompt
        if context:
            full_prompt = context + "\n\n## 현재 질문\n" + prompt
        
        response = chain.invoke(full_prompt)
        return response, None
    except Exception as e:
        error_msg = str(e)
        
        # 에러 유형별 사용자 친화적 메시지
        if "API key" in error_msg or "authentication" in error_msg.lower():
            user_msg = "❌ API Key 오류: OpenAI API Key가 올바르지 않습니다. .env 파일을 확인해주세요."
        elif "rate_limit" in error_msg.lower():
            user_msg = "⏱️ 요청 한도 초과: 잠시 후 다시 시도해주세요."
        elif "timeout" in error_msg.lower():
            user_msg = "⏱️ 시간 초과: 문서가 너무 크거나 네트워크 연결이 불안정합니다."
        else:
            user_msg = f"❌ 오류 발생: {error_msg}"
        
        # 상세 로그는 콘솔에만
        print(f"Error in safe_invoke_chain: {traceback.format_exc()}")
        
        return None, user_msg

# ==========================================
# 헤더
# ==========================================

st.title("📊 World Vision AI 보고서 생성 에이전트 v2.0")
st.markdown("""
> **80% 업무시간 단축을 위한 AI 자동화 솔루션**  
> 회의록, 프로젝트 문서를 업로드하면 구조화된 보고서를 자동으로 생성합니다.
""")

# API Key 체크
if not check_api_key():
    st.error("⚠️ OpenAI API Key가 설정되지 않았습니다. .env 파일을 확인해주세요.")
    st.info("💡 .env 파일에 다음과 같이 입력하세요:\n```\nOPENAI_API_KEY=sk-proj-여기에-키-입력\n```")
    st.stop()

# ==========================================
# 사이드바 설정
# ==========================================

with st.sidebar:
    st.header("⚙️ 설정")
    
    # 파일 업로드
    uploaded_file = st.file_uploader(
        "📄 문서 업로드 (PDF)", 
        type=['pdf'],
        help="회의록, 프로젝트 문서, 데이터 보고서 등을 업로드하세요"
    )
    
    st.divider()
    
    # 보고서 유형 선택
    report_type = st.selectbox(
        "📋 보고서 유형",
        ["업무 보고서", "회의록 요약", "프로젝트 현황", "데이터 분석 보고서"],
        help="생성할 보고서 유형을 선택하세요"
    )
    
    # 고급 설정 (접이식)
    with st.expander("🔧 고급 설정"):
        chunk_size = st.slider("Chunk Size", 200, 1000, 500, 50)
        chunk_overlap = st.slider("Chunk Overlap", 0, 200, 100, 20)
        top_k = st.slider("검색 문서 수 (k)", 1, 10, 3, 1)
        temperature = st.slider("창의성 (Temperature)", 0.0, 1.0, 0.0, 0.1)
        
        # 멀티턴 대화 설정
        max_turns = st.slider("대화 맥락 유지 (턴)", 0, 5, 3, 1, 
                             help="이전 대화를 몇 턴까지 기억할지 설정")
    
    st.divider()
    
    # 대화 초기화 버튼
    if st.button("🔄 대화 초기화", use_container_width=True):
        if "messages" in st.session_state:
            st.session_state.messages = []
            st.success("✅ 대화 기록이 초기화되었습니다.")
            st.rerun()
    
    st.divider()
    st.caption("💡 World Vision AI Platform v2.0")

# ==========================================
# 메인 영역
# ==========================================

if uploaded_file:
    try:
        # 프로그레스 바로 상태 표시
        progress_bar = st.progress(0)
        status_text = st.empty()
        
        # 임시 파일 저장
        status_text.text("📁 파일 업로드 중...")
        progress_bar.progress(20)
        
        temp_path = f"temp_{uploaded_file.name}"
        with open(temp_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
        
        # RAG 체인 초기화 (세션 상태 활용)
        current_settings = (chunk_size, chunk_overlap, top_k, temperature, report_type)
        
        if "rag_chain" not in st.session_state or st.session_state.get("last_settings") != current_settings:
            status_text.text("📚 문서 분석 중...")
            progress_bar.progress(40)
            
            try:
                st.session_state.rag_chain = create_report_rag_chain(
                    temp_path, 
                    report_type=report_type,
                    chunk_size=chunk_size,
                    chunk_overlap=chunk_overlap,
                    top_k=top_k,
                    temperature=temperature
                )
                st.session_state.last_settings = current_settings
                
                progress_bar.progress(100)
                status_text.text("✅ 분석 완료!")
                
            except Exception as e:
                progress_bar.empty()
                status_text.empty()
                st.error(f"❌ 문서 분석 중 오류 발생: {str(e)}")
                st.info("💡 PDF 파일이 올바른지 확인하거나, 다른 파일로 시도해보세요.")
                st.stop()
        else:
            progress_bar.progress(100)
            status_text.text("✅ 이미 분석 완료된 문서입니다.")
        
        # 프로그레스 바 숨기기
        progress_bar.empty()
        status_text.empty()
        
        st.success("✅ 분석 완료! 이제 질문하거나 보고서 생성을 요청하세요.")
        
        # 탭 구성
        tab1, tab2, tab3 = st.tabs(["💬 대화형 질문", "📝 보고서 자동 생성", "📊 사용 통계"])
        
        # ==========================================
        # 탭1: 대화형 질문 (멀티턴 지원)
        # ==========================================
        with tab1:
            st.markdown("### 문서에 대해 질문하세요")
            
            # 멀티턴 대화 안내
            if max_turns > 0:
                st.info(f"💡 이전 대화 {max_turns}턴까지 기억합니다. 후속 질문을 자유롭게 하세요!")
            
            # 메시지 이력 초기화
            if "messages" not in st.session_state:
                st.session_state.messages = []
            
            # 기존 대화 표시
            for message in st.session_state.messages:
                with st.chat_message(message["role"]):
                    st.markdown(message["content"])
            
            # 사용자 입력
            if prompt := st.chat_input("질문을 입력하세요 (예: 이 문서의 핵심 내용은?)"):
                st.session_state.messages.append({"role": "user", "content": prompt})
                with st.chat_message("user"):
                    st.markdown(prompt)
                
                with st.chat_message("assistant"):
                    with st.spinner("🤔 답변 생성 중..."):
                        # 대화 맥락 포함 (멀티턴)
                        context = ""
                        if max_turns > 0:
                            context = format_chat_history(st.session_state.messages[:-1], max_turns)
                        
                        # 안전한 체인 실행
                        response, error = safe_invoke_chain(
                            st.session_state.rag_chain, 
                            prompt, 
                            context
                        )
                        
                        if error:
                            st.error(error)
                            st.info("💡 잠시 후 다시 시도하거나, 다른 질문으로 시도해보세요.")
                        else:
                            st.markdown(response)
                            st.session_state.messages.append({"role": "assistant", "content": response})
        
        # ==========================================
        # 탭2: 보고서 자동 생성
        # ==========================================
        with tab2:
            st.markdown("### 원클릭 보고서 생성")
            st.info("💡 아래 버튼을 클릭하면 업로드한 문서를 기반으로 구조화된 보고서를 자동 생성합니다.")
            
            col1, col2 = st.columns([1, 4])
            with col1:
                generate_button = st.button("📊 보고서 생성", type="primary", use_container_width=True)
            
            if generate_button:
                # 프로그레스 바
                report_progress = st.progress(0)
                report_status = st.empty()
                
                report_status.text("📝 보고서 생성 중... (1/3) 문서 분석")
                report_progress.progress(33)
                
                # 보고서 생성 전용 프롬프트
                current_time = datetime.now().strftime("%Y년 %m월 %d일 %H:%M")
                
                report_prompt = f"""
# 명령문
당신은 World Vision의 업무 보고서 작성 전문가입니다. 
업로드된 문서를 분석하여 '{report_type}' 형식의 구조화된 보고서를 작성해주세요.

# 제약조건
- 비즈니스 관점에서 핵심 내용을 간결하게 작성
- 전문적이고 공식적인 어조 유지
- 문장은 간결하게 작성하되 핵심 정보는 누락하지 않음
- 다른 문장이나 설명은 출력하지 않음

# 입력문
업로드된 문서의 전체 내용을 분석하여 {report_type}를 작성하시오.

# 출력형식
## [제목]
{report_type} - [문서명 또는 주제]

## 1. 요약
- 핵심 내용 3-5줄 요약

## 2. 주요 내용
- 중요 포인트 1
- 중요 포인트 2  
- 중요 포인트 3
(추가 포인트 자유롭게)

## 3. 액션 아이템 (해당 시)
- [ ] 조치 사항 1
- [ ] 조치 사항 2

## 4. 결론 및 제언
- 종합 의견 및 다음 단계

---
*생성일시: {current_time}*
*생성 모델: GPT-4o*
"""
                
                report_status.text("📝 보고서 생성 중... (2/3) AI 처리")
                report_progress.progress(66)
                
                # 안전한 체인 실행
                report, error = safe_invoke_chain(st.session_state.rag_chain, report_prompt)
                
                if error:
                    report_progress.empty()
                    report_status.empty()
                    st.error(error)
                    st.info("💡 잠시 후 다시 시도하거나, 파라미터를 조정해보세요.")
                else:
                    report_status.text("📝 보고서 생성 중... (3/3) 완료")
                    report_progress.progress(100)
                    
                    report_progress.empty()
                    report_status.empty()
                    
                    st.markdown("---")
                    st.markdown("### ✅ 생성된 보고서")
                    st.markdown(report)
                    
                    # 다운로드 버튼
                    col_a, col_b = st.columns(2)
                    with col_a:
                        st.download_button(
                            label="📥 TXT 다운로드",
                            data=report,
                            file_name=f"WV_Report_{uploaded_file.name.replace('.pdf', '')}_{datetime.now().strftime('%Y%m%d')}.txt",
                            mime="text/plain",
                            use_container_width=True
                        )
                    with col_b:
                        st.download_button(
                            label="📥 MD 다운로드",
                            data=report,
                            file_name=f"WV_Report_{uploaded_file.name.replace('.pdf', '')}_{datetime.now().strftime('%Y%m%d')}.md",
                            mime="text/markdown",
                            use_container_width=True
                        )
        
        # ==========================================
        # 탭3: 사용 통계
        # ==========================================
        with tab3:
            st.markdown("### 📊 현재 세션 사용 통계")
            
            # 통계 계산
            if "messages" in st.session_state:
                total_messages = len(st.session_state.messages)
                user_messages = len([m for m in st.session_state.messages if m["role"] == "user"])
                ai_messages = len([m for m in st.session_state.messages if m["role"] == "assistant"])
            else:
                total_messages = user_messages = ai_messages = 0
            
            # 메트릭 표시
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("총 대화 수", total_messages)
            with col2:
                st.metric("질문 수", user_messages)
            with col3:
                st.metric("답변 수", ai_messages)
            
            st.divider()
            
            # 설정 정보
            st.markdown("### ⚙️ 현재 설정")
            settings_data = {
                "보고서 유형": report_type,
                "Chunk Size": chunk_size,
                "Chunk Overlap": chunk_overlap,
                "Top K": top_k,
                "Temperature": temperature,
                "대화 맥락 유지": f"{max_turns} 턴"
            }
            
            for key, value in settings_data.items():
                st.text(f"{key}: {value}")
    
    except Exception as e:
        st.error(f"❌ 예상치 못한 오류가 발생했습니다: {str(e)}")
        st.info("💡 페이지를 새로고침하거나, 다른 PDF 파일로 시도해보세요.")
        print(f"Main error: {traceback.format_exc()}")

else:
    # ==========================================
    # 안내 메시지
    # ==========================================
    st.info("👈 왼쪽 사이드바에서 PDF 파일을 업로드하여 시작하세요.")
    
    # 사용 예시
    with st.expander("📖 사용 가이드"):
        st.markdown("""
        ### 사용 방법
        
        1. **문서 업로드**: 왼쪽 사이드바에서 PDF 파일 업로드
        2. **보고서 유형 선택**: 생성할 보고서 형식 선택
        3. **대화형 질문 또는 자동 생성 선택**:
           - 💬 대화형: 문서에 대해 자유롭게 질문 (멀티턴 대화 지원!)
           - 📝 자동 생성: 원클릭으로 구조화된 보고서 생성
        
        ### 🆕 v2.0 신규 기능
        - ✅ **멀티턴 대화**: 이전 대화 맥락을 기억하여 자연스러운 후속 질문 가능
        - ✅ **에러 핸들링**: 오류 발생 시 사용자 친화적 메시지 표시
        - ✅ **프로그레스 바**: 문서 분석 및 보고서 생성 진행 상황 실시간 표시
        - ✅ **사용 통계**: 현재 세션의 질문/답변 횟수 확인
        - ✅ **대화 초기화**: 언제든 대화 기록 초기화 가능
        
        ### 활용 사례
        - ✅ 회의록을 업로드하여 핵심 내용 자동 요약
        - ✅ 프로젝트 문서를 현황 보고서로 변환
        - ✅ 데이터 분석 결과를 경영진 보고서로 정리
        - ✅ 다국어 문서를 한국어 보고서로 번역 및 요약
        
        ### 고급 기능
        - 🔧 Chunk Size: 문서 분할 크기 조정 (작을수록 정밀, 클수록 문맥 유지)
        - 🔧 Overlap: 청크 간 중복 비율 (높을수록 문맥 연결성 향상)
        - 🔧 Top K: 검색할 관련 문서 수 (많을수록 풍부하지만 느림)
        - 🔧 Temperature: AI 창의성 (0=정확, 1=창의적)
        - 🔧 대화 맥락 유지: 이전 대화를 몇 턴까지 기억할지 설정
        """)
    
    # 데모 영상 또는 스크린샷 공간
    st.markdown("---")
    st.caption("World Vision AI Platform v2.0 | Powered by GPT-4o & LangChain")
