"""
RAGAS 기반 RAG 시스템 자동 평가 모듈
- Faithfulness (충실도): 답변이 검색된 문서에 기반하는가
- Answer Relevancy (답변 관련성): 질문에 적절한 답변인가
- Context Precision (맥락 정확도): 검색된 문서가 관련있는가
- Context Recall (맥락 재현율): 필요한 문서를 충분히 검색했는가
"""

import os
from datasets import Dataset
from ragas import evaluate
from ragas.metrics import (
    faithfulness,
    answer_relevancy,
    context_precision,
    context_recall
)

def evaluate_rag_system(questions, answers, contexts, ground_truths=None):
    """
    RAGAS를 사용한 RAG 시스템 자동 평가
    
    Args:
        questions (list): 질문 리스트
        answers (list): 생성된 답변 리스트
        contexts (list): 검색된 문맥 리스트 (각 항목은 list of strings)
        ground_truths (list, optional): 정답 리스트 (Context Recall 계산용)
    
    Returns:
        dict: 평가 결과 (faithfulness, answer_relevancy, context_precision, context_recall)
    """
    
    # Dataset 생성
    data = {
        "question": questions,
        "answer": answers,
        "contexts": contexts,
    }
    
    # Ground truth가 있으면 추가
    if ground_truths:
        data["ground_truth"] = ground_truths
    
    dataset = Dataset.from_dict(data)
    
    # 평가 메트릭 선택
    metrics = [
        faithfulness,
        answer_relevancy,
        context_precision,
    ]
    
    # Ground truth가 있을 때만 context_recall 추가
    if ground_truths:
        metrics.append(context_recall)
    
    # 평가 실행
    result = evaluate(
        dataset,
        metrics=metrics,
    )
    
    return result


def format_ragas_results(result):
    """
    RAGAS 평가 결과를 보기 좋게 포맷팅
    
    Args:
        result: RAGAS evaluate() 결과
    
    Returns:
        str: 포맷팅된 결과 문자열
    """
    
    output = "\n📊 RAGAS 자동 평가 결과\n"
    output += "=" * 50 + "\n\n"
    
    # Faithfulness (충실도)
    if 'faithfulness' in result:
        score = result['faithfulness']
        output += f"✅ Faithfulness (충실도): {score:.3f}\n"
        output += f"   → 답변이 검색된 문서에 얼마나 충실한가\n"
        output += f"   → 점수가 높을수록 환각(Hallucination) 없음\n\n"
    
    # Answer Relevancy (답변 관련성)
    if 'answer_relevancy' in result:
        score = result['answer_relevancy']
        output += f"✅ Answer Relevancy (답변 관련성): {score:.3f}\n"
        output += f"   → 질문에 대한 답변의 적절성\n"
        output += f"   → 점수가 높을수록 질문과 관련된 답변\n\n"
    
    # Context Precision (맥락 정확도)
    if 'context_precision' in result:
        score = result['context_precision']
        output += f"✅ Context Precision (맥락 정확도): {score:.3f}\n"
        output += f"   → 검색된 문서가 얼마나 관련있는가\n"
        output += f"   → 점수가 높을수록 불필요한 문서 적음\n\n"
    
    # Context Recall (맥락 재현율)
    if 'context_recall' in result:
        score = result['context_recall']
        output += f"✅ Context Recall (맥락 재현율): {score:.3f}\n"
        output += f"   → 필요한 문서를 충분히 검색했는가\n"
        output += f"   → 점수가 높을수록 필요한 정보 누락 적음\n\n"
    
    output += "=" * 50 + "\n"
    output += "💡 점수 해석: 0.0 (최저) ~ 1.0 (최고)\n"
    output += "   0.8 이상: 우수\n"
    output += "   0.6-0.8: 양호\n"
    output += "   0.6 미만: 개선 필요\n"
    
    return output


def quick_evaluate(rag_chain, test_questions):
    """
    간단한 테스트 질문으로 빠르게 평가
    
    Args:
        rag_chain: RAG 체인 객체
        test_questions (list): 테스트 질문 리스트
    
    Returns:
        dict: 평가 결과
    """
    
    questions = []
    answers = []
    contexts = []
    
    print("🔄 평가 중...")
    
    for i, question in enumerate(test_questions, 1):
        print(f"   질문 {i}/{len(test_questions)} 처리 중...")
        
        # RAG 체인 실행
        answer = rag_chain.invoke(question)
        
        # 검색된 문서 가져오기 (retriever에서)
        retrieved_docs = rag_chain.retriever.get_relevant_documents(question)
        context = [doc.page_content for doc in retrieved_docs]
        
        questions.append(question)
        answers.append(answer)
        contexts.append(context)
    
    print("✅ 평가 데이터 수집 완료!\n")
    
    # RAGAS 평가 실행
    result = evaluate_rag_system(questions, answers, contexts)
    
    return result


# 테스트 질문 세트 (World Vision 업무 관련)
DEFAULT_TEST_QUESTIONS = [
    "이 문서의 주요 내용은 무엇인가요?",
    "핵심 결론을 3줄로 요약해주세요.",
    "주요 액션 아이템은 무엇인가요?",
    "이 문서에서 가장 중요한 포인트는?",
    "다음 단계로 진행할 사항은 무엇인가요?"
]


if __name__ == "__main__":
    # 테스트 예제
    print("RAGAS 평가 모듈 로드 완료!")
    print("\n사용 예시:")
    print("```python")
    print("from ragas_evaluator import evaluate_rag_system, format_ragas_results")
    print("")
    print("# 평가 실행")
    print("result = evaluate_rag_system(questions, answers, contexts)")
    print("")
    print("# 결과 출력")
    print("print(format_ragas_results(result))")
    print("```")
