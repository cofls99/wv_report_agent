# 🚀 AWS App Runner 배포 가이드

## 📋 사전 준비

### 1️⃣ AWS 계정 생성
1. https://aws.amazon.com/ 접속
2. "Create an AWS Account" 클릭
3. 이메일, 비밀번호, 계정 이름 입력
4. 결제 정보 입력 (프리티어는 대부분 무료)
5. 본인 확인 완료

### 2️⃣ AWS CLI 설치

#### Windows
```powershell
# MSI 설치 파일 다운로드
https://awscli.amazonaws.com/AWSCLIV2.msi

# 설치 후 확인
aws --version
```

#### Mac
```bash
curl "https://awscli.amazonaws.com/AWSCLIV2.pkg" -o "AWSCLIV2.pkg"
sudo installer -pkg AWSCLIV2.pkg -target /
aws --version
```

#### Linux
```bash
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install
aws --version
```

### 3️⃣ AWS 자격 증명 설정
```bash
aws configure
# AWS Access Key ID: [입력]
# AWS Secret Access Key: [입력]
# Default region: us-east-1
# Default output format: json
```

---

## 🔧 방법 1: AWS ECR + App Runner (권장)

### Step 1: ECR 리포지토리 생성
```bash
# ECR 리포지토리 생성
aws ecr create-repository --repository-name wv-report-agent --region us-east-1
```

### Step 2: Docker 이미지 빌드
```bash
# 프로젝트 디렉토리에서
docker build -t wv-report-agent .
```

### Step 3: ECR 로그인
```bash
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin [YOUR_ACCOUNT_ID].dkr.ecr.us-east-1.amazonaws.com
```

### Step 4: 이미지 태그 및 푸시
```bash
# 이미지 태그
docker tag wv-report-agent:latest [YOUR_ACCOUNT_ID].dkr.ecr.us-east-1.amazonaws.com/wv-report-agent:latest

# 이미지 푸시
docker push [YOUR_ACCOUNT_ID].dkr.ecr.us-east-1.amazonaws.com/wv-report-agent:latest
```

### Step 5: App Runner 서비스 생성

1. **AWS Console 접속**
   - https://console.aws.amazon.com/apprunner/

2. **서비스 생성**
   - "Create service" 클릭
   - Source: "Container registry"
   - Provider: "Amazon ECR"
   - Image URI: 위에서 푸시한 이미지 선택
   - Deployment trigger: "Manual"

3. **서비스 설정**
   - Service name: `wv-report-agent`
   - CPU: 1 vCPU
   - Memory: 2 GB
   - Port: 8501

4. **환경 변수 설정**
   - Key: `OPENAI_API_KEY`
   - Value: [Your OpenAI API Key]

5. **배포 완료**
   - "Create & deploy" 클릭
   - 3-5분 대기
   - URL 생성됨: `https://xxxxx.us-east-1.awsapprunner.com`

---

## 🎯 방법 2: GitHub + App Runner (간편)

### Step 1: GitHub 리포지토리 생성
1. GitHub에 새 리포지토리 생성
2. 프로젝트 파일 업로드

### Step 2: App Runner 서비스 생성
1. AWS Console → App Runner
2. "Create service"
3. Source: "Source code repository"
4. Provider: "GitHub"
5. GitHub 연결 및 리포지토리 선택
6. Runtime: "Python 3"
7. Build command: `pip install -r requirements.txt`
8. Start command: `streamlit run app.py --server.port=8501 --server.address=0.0.0.0`
9. 환경 변수 설정 (OPENAI_API_KEY)
10. "Create & deploy"

---

## 📊 배포 확인

### 1. 상태 확인
```bash
aws apprunner list-services --region us-east-1
```

### 2. URL 접속
```
https://xxxxx.us-east-1.awsapprunner.com
```

### 3. 로그 확인
```bash
aws apprunner list-operations --service-arn [YOUR_SERVICE_ARN] --region us-east-1
```

---

## 💰 비용 관리

### 프리티어 (12개월)
- App Runner: 월 300시간 무료
- ECR: 500MB 스토리지 무료

### 예상 비용
- CPU (1 vCPU): $0.064/시간
- Memory (2GB): $0.007/GB/시간
- 총 예상: **월 $50-70** (24시간 운영 시)

### 비용 절감 팁
1. 사용하지 않을 때 서비스 일시 중지
2. Auto scaling 설정
3. CloudWatch로 모니터링

---

## 🐛 트러블슈팅

### 이미지 빌드 실패
```bash
# Docker 버전 확인
docker --version

# 빌드 로그 확인
docker build -t wv-report-agent . --no-cache
```

### 배포 실패
- ECR 이미지 URI 정확한지 확인
- 환경 변수 (OPENAI_API_KEY) 설정 확인
- 포트 8501 설정 확인

### 502 Bad Gateway
- Streamlit 서버가 제대로 시작되는지 확인
- 로그 확인: AWS Console → App Runner → Logs

---

## 📝 배포 체크리스트

- [ ] AWS 계정 생성 완료
- [ ] AWS CLI 설치 완료
- [ ] Docker 설치 완료 (선택)
- [ ] .env 파일에 API Key 입력
- [ ] ECR 리포지토리 생성
- [ ] Docker 이미지 빌드 및 푸시
- [ ] App Runner 서비스 생성
- [ ] 환경 변수 설정
- [ ] 배포 완료 및 URL 확인
- [ ] 실제 동작 테스트

---

## 🎓 추가 참고 자료

- [AWS App Runner 공식 문서](https://docs.aws.amazon.com/apprunner/)
- [ECR 사용 가이드](https://docs.aws.amazon.com/ecr/)
- [Docker 튜토리얼](https://docs.docker.com/get-started/)

---

**작성일**: 2026.01.26  
**버전**: v2.0
